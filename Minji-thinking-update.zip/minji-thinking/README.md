# Minji 思考动作修正版

这版将原来的工作动作改成六帧循环：托腮、轻点下巴、短暂眨眼，再自然回到起始姿势。动作中没有电脑、键盘或敲击手势。

- `spritesheet.webp`：可用的 v2 桌宠图集（1536 × 2288）
- `pet.json`：桌宠元数据
- `previews/running.gif`：本次修改的思考动作预览
- `qa/contact-sheet.png`：全部动作帧总览
- `qa/direction-sheet.png`：16 方位检查图
- `qa/*.json`：结构、透明边缘、连续性和未修改行一致性检查
- `source/`：本次托腮动作的源图、角色基准图和生成提示，便于以后继续修改

云端桌宠 ID：`pet_6abb7bf2482c8191b0f907ecf659a155`。更新时保留了原来的名称、描述和启用状态。
